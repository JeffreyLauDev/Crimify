export const SERVER_URL = 'https://localhost:8443'
